## Link a draw.io con el ejercicio<br>

* https://drive.google.com/file/d/1xG8N3UayZEhZgvVyjcEGjtpZ2FCrvABL/view?usp=sharing